'use strict';

publishExternalAPI(angular);
